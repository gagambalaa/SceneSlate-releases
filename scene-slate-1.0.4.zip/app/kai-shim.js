// Scene Slate was first written against a hosted page's shared database (claude.use('db') / claude.use('user')).
// Here the same calls are served by this plugin's own server, which keeps every document as a file in the project's
// Scene Slate folder - so the app above this line of the stack didn't have to change.
//   db.collection(name).onSnapshot(cb)   cb({docs: [{id, data()}]}) now and on every change (any tab, any artist)
//   db.doc('collection/id').set(obj) / .delete()   -> Promise
//   user.id() -> who is working · user.can('data.write') -> true
(function () {
  'use strict';
  var cols = {}, got = {}, subs = {}, home = null, moved = false;
  function snap(c) { var d = cols[c] || {}; return { docs: Object.keys(d).map(function (id) { return { id: id, data: function () { return d[id]; } }; }) }; }
  function fire(c) { (subs[c] || []).forEach(function (cb) { try { cb(snap(c)); } catch (e) { console.error(e); } }); }

  var es = new EventSource('/api/events');
  // the show itself changed (not the work on top of it): load it again, once nobody is typing
  es.addEventListener('base', function () {
    var go = function () { var a = document.activeElement; if (a && a.getAttribute && a.getAttribute('contenteditable')) return setTimeout(go, 3000); location.reload(); };
    go();
  });
  es.addEventListener('db', function (e) { var m = JSON.parse(e.data); cols[m.col] = m.docs || {}; got[m.col] = true; fire(m.col); });
  // the server was moved to another project's folder (KAI opened Scene Slate for another project): this tab stops here
  es.addEventListener('home', function (e) {
    var dir = JSON.parse(e.data).dir;
    if (!home) { home = dir; return; }
    if (home === dir || moved) return;
    moved = true; es.close();
    var el = document.createElement('div');
    el.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(23,20,15,.93);color:#fff;font:15px/1.5 system-ui,sans-serif;text-align:center;padding:24px';
    el.innerHTML = '<div><b style="font-size:18px">Scene Slate is now open for another project</b><br>Everything here was saved. Go back to the canvas and open it again for this project.</div>';
    document.body.appendChild(el);
    try { if (window.parent !== window) window.parent.postMessage({ kai_plugin: 'moved' }, '*'); } catch (err) {}
  });

  function call(method, c, id, body) {
    if (moved) return Promise.reject(new Error('Scene Slate is open for another project now'));
    return fetch('/api/db/' + c + '/' + encodeURIComponent(id), { method: method, headers: { 'content-type': 'application/json' }, body: body == null ? undefined : JSON.stringify(body), keepalive: true })
      .then(function (r) { if (!r.ok) throw new Error('save failed'); });
  }
  var db = {
    collection: function (c) {
      return { onSnapshot: function (cb) { (subs[c] = subs[c] || []).push(cb); if (got[c]) cb(snap(c)); return function () { subs[c] = subs[c].filter(function (x) { return x !== cb; }); }; } };
    },
    doc: function (p) {
      var i = p.indexOf('/'), c = p.slice(0, i), id = p.slice(i + 1);
      return {
        set: function (v) { (cols[c] = cols[c] || {})[id] = v; return call('PUT', c, id, v); },
        delete: function () { if (cols[c]) delete cols[c][id]; return call('DELETE', c, id); }
      };
    }
  };
  var meP = fetch('/api/me').then(function (r) { return r.json(); }).then(function (j) { return j.id || null; }, function () { return null; });
  var user = { id: function () { return meP; }, can: function () { return Promise.resolve(true); } };
  window.claude = { use: function (n) { return Promise.resolve(n === 'db' ? db : n === 'user' ? user : null); } };

  // what a browser remembers (open episodes, the last scene, a typed title) is per show: another project starts clean
  try {
    var here = (window.__SHOW__ || {}).home || '';
    if (localStorage.getItem('sh.home') !== here) {
      Object.keys(localStorage).filter(function (k) { return k.indexOf('sh.') === 0; }).forEach(function (k) { localStorage.removeItem(k); });
      localStorage.setItem('sh.home', here);
    }
  } catch (e) {}
})();

// ---------- Blocking Board: how the scene on screen was staged - a section of the scene page ----------
// The page calls window.kaiScene(id | null) whenever it shows a scene (or leaves one). The section (before "Ask Claude
// to revise") says whether the board has that scene, shows each shot's frame - in the film's frame, 9:16 for a vertical
// show - with its blocking line, and opens the scene's board (through KAI inside it, else Blocking Board's own page).
// It's drawn in the slate's own look (h3.sec, its colours) and put back whenever the page redraws the scene.
(function () {
  'use strict';
  var cur = null, info = null, el = null, timer = null;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var css = document.createElement('style');
  css.textContent =
    '#kaiBB .bbshots{display:flex;gap:12px;overflow-x:auto;padding:2px 0 8px}' +
    '#kaiBB .bbshot{flex:none;width:200px;background:var(--panel);border:1px solid var(--rule);border-radius:3px;overflow:hidden;display:flex;flex-direction:column}' +
    '#kaiBB .bbshot.tall{width:150px}' +
    '#kaiBB .bbimg{width:100%;background:var(--sunk);display:flex;align-items:center;justify-content:center;color:var(--faint);font-size:.72rem;cursor:pointer}' +
    '#kaiBB .bbimg img{width:100%;height:100%;object-fit:cover;display:block}' +
    '#kaiBB .bbtxt{padding:7px 9px 9px;display:flex;flex-direction:column;gap:4px;font-size:.8rem}' +
    '#kaiBB .bbname{font-family:"Barlow Condensed",sans-serif;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--ink)}' +
    '#kaiBB .bbname span{color:var(--faint);font-weight:500;margin-left:6px}' +
    '#kaiBB .bbline{color:var(--dim);line-height:1.35;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}' +
    '#kaiBB .bbcopy{align-self:flex-start;font-family:"Barlow Condensed",sans-serif;font-size:.7rem;font-weight:600;letter-spacing:.09em;text-transform:uppercase;padding:2px 9px;border:1px solid var(--rule);border-radius:2px;background:var(--panel);color:var(--dim);cursor:pointer}' +
    '#kaiBB .note{display:flex;align-items:center;gap:12px}';
  document.head.appendChild(css);
  function board() {
    if (!cur) return;
    if (window.parent !== window) window.parent.postMessage({ kai_plugin: 'open', id: 'blocking-board', open: { slate: cur } }, '*');
    else window.open('http://127.0.0.1:5317/#slate=' + encodeURIComponent(cur), 'blocking-board');
  }
  function html() {
    var a = String((info && info.aspect) || '16:9').split(':'), ar = (+a[0] || 16) + ' / ' + (+a[1] || 9), tall = +a[0] < +a[1];
    if (!info.staged)
      return '<h3 class="sec">Blocking Board<button data-bb="open">Stage it</button></h3>' +
        '<div class="note"><span>Not on the Blocking Board yet - staging it lays its shots out in 3D for the camera.</span></div>';
    var n = info.shots.length;
    return '<h3 class="sec">Blocking Board \u00b7 ' + esc(info.ep) + ' \u203a ' + esc(info.sc) + ' \u00b7 ' + n + ' shot' + (n === 1 ? '' : 's') +
      '<button data-bb="open">Open board</button></h3>' +
      (n && info.shots.some(function (s) { return s.board; }) ? '<div class="note"><span>This scene\u2019s prompts use the board\u2019s camera' +
        (info.shots.some(function (s) { return s.board && s.board.light; }) ? ', and the light set on the board' : '') + '.</span></div>' : '') +
      (n ? '<div class="bbshots">' + info.shots.map(function (s) {
        return '<div class="bbshot' + (tall ? ' tall' : '') + '"><div class="bbimg" data-bb="open" style="aspect-ratio:' + ar + '" title="Open this scene on the board">' +
          (s.frame ? '<img src="' + esc(s.frame) + '" alt="" loading="lazy">' : 'no frame yet') + '</div>' +
          '<div class="bbtxt"><div class="bbname">' + esc(s.name) + '<span>' + esc(s.sec) + ' s</span></div>' +
          '<div class="bbline">' + esc(s.blocking || 'No blocking yet') + '</div>' +
          (s.blocking ? '<button class="bbcopy" data-bb="copy" data-text="' + esc(s.blocking) + '">Copy</button>' : '') + '</div></div>';
      }).join('') + '</div>'
        : '<div class="note"><span>Staged - no shot has a camera yet.</span></div>');
  }
  function place() {   // (before "Ask Claude to revise", else before the sequence prompt, else at the end of the scene)
    var body = document.getElementById('body');
    if (!body || !cur || !info || !info.board) { if (el && el.parentNode) el.remove(); return; }
    if (!el) {
      el = document.createElement('section'); el.id = 'kaiBB';
      el.addEventListener('click', function (e) {
        var a = e.target.closest('[data-bb]'); if (!a) return;
        if (a.dataset.bb === 'open') board();
        else if (a.dataset.bb === 'copy') { try { navigator.clipboard.writeText(a.dataset.text || ''); a.textContent = 'Copied'; setTimeout(function () { a.textContent = 'Copy'; }, 1200); } catch (err) {} }
      });
    }
    var want = html();
    if (el.dataset.h !== want) { el.innerHTML = want; el.dataset.h = want; }
    if (el.parentNode === body && el.dataset.at === cur) return;
    var heads = Array.prototype.slice.call(body.querySelectorAll('h3.sec')).filter(function (h) { return !el.contains(h); });
    var at = heads.find(function (h) { return /^ask claude/i.test(h.textContent); }) || heads.find(function (h) { return /^sequence prompt/i.test(h.textContent); });
    if (at) at.parentNode.insertBefore(el, at); else body.appendChild(el);
    el.dataset.at = cur;
  }
  // a staged scene's camera (and light set on the board) for the page's prompts - redrawn when it changes
  function keepBoard(j) {
    var B = window.__BOARD__ = window.__BOARD__ || {}, was = JSON.stringify(B[cur] || null), now = null;
    if (j && j.staged) {
      var shots = {};
      (j.shots || []).forEach(function (s) { if (s.board && s.id) shots[s.id] = s.board; });
      if (Object.keys(shots).length) now = { shots: shots };
    }
    if (now) B[cur] = now; else delete B[cur];
    if (JSON.stringify(now) !== was) window.dispatchEvent(new Event('kai-board'));
  }
  function load() {
    if (!cur) { info = null; return place(); }
    var want = cur;
    fetch('/api/blocking?scene=' + encodeURIComponent(want)).then(function (r) { return r.json(); }).then(function (j) { if (want === cur) { info = j; keepBoard(j); place(); } }, function () {});
  }
  window.kaiScene = function (id) { if (id === cur) return place(); cur = id || null; info = null; if (el) el.dataset.at = ''; place(); load(); };
  // the page redraws the scene now and then (an edit, a filter): the section goes back where it belongs
  var mo = new MutationObserver(function () { if (cur && info && el && !document.getElementById('kaiBB')) { el.dataset.at = ''; place(); } });
  function watch() { var b = document.getElementById('body'); if (b) mo.observe(b, { childList: true }); else setTimeout(watch, 300); }
  watch();
  // the board moves on while the slate is open: look again now and then, and when the window comes back
  clearInterval(timer); timer = setInterval(function () { if (cur && document.visibilityState === 'visible') load(); }, 8000);
  addEventListener('focus', load);
})();

// ---------- the slate's shape, from the scene page: a scene after this one, merged into the one before, removed (kept
// aside - restorable from "Removed scenes"). The server renumbers; the Blocking Board and KAI's tables follow. ----------
(function () {
  'use strict';
  var cur = null, row = null, pop = null;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var css = document.createElement('style');
  css.textContent =
    '#kaiActs{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}' +
    '#kaiActs button,#kaiRm button{font-family:"Barlow Condensed",sans-serif;font-size:.7rem;font-weight:600;letter-spacing:.09em;text-transform:uppercase;padding:3px 10px;border:1px solid var(--rule);border-radius:2px;background:var(--panel);color:var(--dim);cursor:pointer}' +
    '#kaiActs button:hover,#kaiRm button:hover{color:var(--ink)}#kaiActs button.red{color:var(--blood)}' +
    '#kaiRm{position:fixed;inset:0;z-index:80;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center}' +
    '#kaiRm .box{background:var(--panel);border:1px solid var(--rule);border-radius:4px;width:min(560px,92vw);max-height:76vh;overflow:auto;padding:16px 18px;color:var(--ink)}' +
    '#kaiRm h3{font-family:"Barlow Condensed",sans-serif;letter-spacing:.12em;text-transform:uppercase;font-size:.85rem;color:var(--blood);margin:0 0 10px}' +
    '#kaiRm .it{display:flex;gap:10px;align-items:center;padding:8px 0;border-top:1px solid var(--rule);font-size:.85rem}#kaiRm .it div{flex:1;min-width:0}' +
    '#kaiRm .it small{color:var(--faint);display:block}';
  document.head.appendChild(css);
  function api(op, body) {
    return fetch('/api/scene/' + op, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error(j.error || 'not done'); return j; });
  }
  // the page's own dialogs: the browser's confirm() / prompt() don't open in a frame of another origin (KAI's window)
  function ask(text, opt) {
    opt = opt || {};
    return new Promise(function (done) {
      var d = document.createElement('div'); d.id = 'kaiRm';
      d.innerHTML = '<div class="box" style="width:min(460px,92vw)"><div style="white-space:pre-wrap;line-height:1.45;font-size:.9rem">' + esc(text) + '</div>' +
        (opt.input != null ? '<input value="' + esc(opt.input) + '" style="width:100%;margin-top:12px;padding:7px 9px;font:inherit;background:var(--sunk);color:var(--ink);border:1px solid var(--rule);border-radius:3px">' : '') +
        '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">' + (opt.only ? '' : '<button data-k="no">Cancel</button>') +
        '<button data-k="ok"' + (opt.red ? ' style="color:var(--blood)"' : '') + '>' + esc(opt.ok || 'OK') + '</button></div></div>';
      var inp = d.querySelector('input');
      function end(v) { d.remove(); removeEventListener('keydown', key, true); done(v); }
      function yes() { end(inp ? inp.value : true); }
      function key(e) { if (e.key === 'Escape') { e.stopPropagation(); end(null); } if (e.key === 'Enter') { e.stopPropagation(); e.preventDefault(); yes(); } }
      d.addEventListener('click', function (e) { var k = e.target.closest('[data-k]'); if (e.target === d || (k && k.dataset.k === 'no')) end(null); else if (k) yes(); });
      addEventListener('keydown', key, true);
      document.body.appendChild(d);
      if (inp) { inp.focus(); inp.select(); }
    });
  }
  function tell(t) { return ask(t, { only: true }); }
  function scenes() { return (window.__SCENES__ || []).slice(); }   // (the show as the server gave it; the page reloads when its shape changes)
  function me() { return scenes().find(function (b) { return b._file === cur; }); }
  function say(t) { var s = row && row.querySelector('span'); if (s) { s.textContent = t; setTimeout(function () { if (s.textContent === t) s.textContent = ''; }, 5000); } }
  function act(e) {
    var a = e.target.closest('[data-sa]'); if (!a) return;
    var b = me(); if (!b) return;
    var prev = scenes().filter(function (x) { return x._ep === b._ep && x._sc === b._sc - 1; })[0];
    var fail = function (err) { tell(err.message); };
    if (a.dataset.sa === 'add') {
      ask('New scene after EP' + b._ep + ' S' + b._sc + ' - its title:', { input: 'New scene', ok: 'Add scene' }).then(function (t) {
        if (t == null) return;
        api('add', { ep: b._ep, after: b._file, title: t }).then(function (r) { say('Added ' + r.title); }, fail); });
    } else if (a.dataset.sa === 'merge') {
      if (!prev) return tell('This is the first scene of the episode - there is none before it to merge into.');
      ask('Merge "' + b.title + '" into "' + prev.title + '"?\n\nIts shots go after that scene\u2019s, with their keyframes and edits; the Blocking Board does the same with its shots. This scene is kept aside (Removed scenes) and the scenes after it renumber.', { ok: 'Merge' }).then(function (y) {
        if (y) api('merge', { id: b._file, into: prev._file }).then(function () { say('Merged'); }, fail); });
    } else if (a.dataset.sa === 'remove') {
      ask('Remove "' + b.title + '"?\n\nIt is kept aside - with its Blocking Board scene - and can be restored from Removed scenes. The scenes after it renumber.', { ok: 'Remove', red: true }).then(function (y) {
        if (y) api('remove', { id: b._file }).then(function () { say('Removed'); }, fail); });
    } else if (a.dataset.sa === 'removed') showRemoved();
  }
  function showRemoved() {
    fetch('/api/scene/removed').then(function (r) { return r.json(); }).then(function (j) {
      if (pop) pop.remove();
      pop = document.createElement('div'); pop.id = 'kaiRm'; pop.className = 'list';
      pop.innerHTML = '<div class="box"><h3>Removed scenes</h3>' + (j.removed.length ? j.removed.map(function (r) {
        return '<div class="it"><div>' + esc(r.title) + '<small>' + (r.into ? 'merged into another scene' : 'removed') + (r.by ? ' by ' + esc(r.by) : '') + (r.at ? ' \u00b7 ' + new Date(r.at).toLocaleString() : '') + '</small></div>' +
          '<button data-rs="' + esc(r.id) + '">Restore</button></div>';
      }).join('') : '<div class="it"><div>None.</div></div>') + '<div style="text-align:right;margin-top:12px"><button data-rs="">Close</button></div></div>';
      pop.addEventListener('click', function (e) {
        if (e.target === pop) return pop.remove();
        var b = e.target.closest('[data-rs]'); if (!b) return;
        if (!b.dataset.rs) return pop.remove();
        api('restore', { id: b.dataset.rs }).then(function (r) { pop.remove(); say('Restored ' + r.title); }, function (err) { tell(err.message); });
      });
      document.body.appendChild(pop);
    });
  }
  function place() {
    var head = document.querySelector('#body header.sc');
    if (!cur || !head || document.querySelector('#body .robar')) { if (row && row.parentNode) row.remove(); return; }   // (not in the read-only view)
    if (!row) {
      row = document.createElement('div'); row.id = 'kaiActs';
      row.innerHTML = '<button data-sa="add">\uff0b Scene after</button><button data-sa="merge">\u21e1 Merge into previous</button>' +
        '<button data-sa="remove" class="red">Remove scene</button><button data-sa="removed">Removed scenes</button><span style="align-self:center;font-size:.78rem;color:var(--dim)"></span>';
      row.addEventListener('click', act);
    }
    if (row.parentNode !== head) head.appendChild(row);
  }
  var was = window.kaiScene;
  window.kaiScene = function (id) { cur = id || null; place(); if (was) was(id); };
  new MutationObserver(function () { if (cur && !document.getElementById('kaiActs')) place(); })
    .observe(document.documentElement, { childList: true, subtree: true });
})();
