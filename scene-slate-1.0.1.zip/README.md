# Scene Slate

The show's slate: every scene's globals and shots, the cast, the style blocks, and the sequence and keyframe prompts
assembled from them. Scene Slate is a KAI plugin: installed with KAI, it has its own tab on KAI's canvas, opens inside
KAI's window, and keeps each show in the KAI project's `KAI\Scene Slate\` folder.

- **A scene is one generation unit** - globals once, shots as rows, the sequence prompt assembled from both.
- **Keyframes** - a prompt per keyframe; approve one and paste back the prompt that made it.
- **Style blocks** - still, scene and animation style, set once and used everywhere.
- **Cast** - each character's spine and their state per episode.
- **Notes and review** - notes on a scene, and a status per scene (to do, in review, ready).
- **Saved in the project** - every change is a small file in the project's folder, written as you make it.

## Running it

Normally KAI installs, updates and starts it (KAI → Settings → App → Plugins). On its own:

```
node tools/import-show.mjs <export.json> ./show
node server/index.mjs          # http://127.0.0.1:5318
npm test
```

## For its developers

You change this plugin and publish it yourself; KAI's owner doesn't have to do anything. Every KAI that has it then
shows that an update is there (a dot on its tab, an Update button) and installs it when the artist says so.

**Set up (once)**

1. Install [Node.js](https://nodejs.org) 20 or newer and Git. Accept the two GitHub invitations (this repo, and
   `SceneSlate-releases`).
2. `git clone https://github.com/gagambalaa/SceneSlate.git`. It has no dependencies, so there's nothing to install.
3. To see your working copy inside KAI on your PC: close KAI, add the folder to KAI's `config.json` -
   `"plugins": ["C:\\path\\to\\SceneSlate"]` - and start KAI again. Its tab now runs your copy (Settings → App → Plugins
   says "developer copy"). Changes to the screen show when you reopen it; after changing `server/`, press
   **Restart** next to it in Settings → App → Plugins.

**Change, test, publish**

1. Make the change. `npm test` must pass.
2. Raise the version: `npm version patch --no-git-tag-version` (`minor` for something new, `major` when data changes
   shape). Commit and `git push`.
3. `node tools/release.mjs --publish` - builds the package and pushes it to `SceneSlate-releases`. Within a few minutes every
   KAI offers the update.

A release can't be taken back once artists have installed it: publish a fixed one with a higher version instead.
Never put keys, passwords or a project's files in either repo. Read `AGENTS.md` before changing how data is stored
or shared - other artists' work and the other plugin depend on it.
