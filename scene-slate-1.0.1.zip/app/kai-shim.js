// Scene Slate was first written against a hosted page's shared database (claude.use('db') / claude.use('user')).
// Here the same calls are served by this plugin's own server, which keeps every document as a file in the project's
// Scene Slate folder - so the app above this line of the stack didn't have to change.
//   db.collection(name).onSnapshot(cb)   cb({docs: [{id, data()}]}) now and on every change (any tab, any artist)
//   db.doc('collection/id').set(obj) / .delete()   -> Promise
//   user.id() -> who is working · user.can('data.write') -> true
(function () {
  'use strict';
  var cols = {}, got = {}, subs = {}, home = null, moved = false;
  function snap(c) { var d = cols[c] || {}; return { docs: Object.keys(d).map(function (id) { return { id: id, data: function () { return d[id]; } }; }) }; }
  function fire(c) { (subs[c] || []).forEach(function (cb) { try { cb(snap(c)); } catch (e) { console.error(e); } }); }

  var es = new EventSource('/api/events');
  // the show itself changed (not the work on top of it): load it again, once nobody is typing
  es.addEventListener('base', function () {
    var go = function () { var a = document.activeElement; if (a && a.getAttribute && a.getAttribute('contenteditable')) return setTimeout(go, 3000); location.reload(); };
    go();
  });
  es.addEventListener('db', function (e) { var m = JSON.parse(e.data); cols[m.col] = m.docs || {}; got[m.col] = true; fire(m.col); });
  // the server was moved to another project's folder (KAI opened Scene Slate for another project): this tab stops here
  es.addEventListener('home', function (e) {
    var dir = JSON.parse(e.data).dir;
    if (!home) { home = dir; return; }
    if (home === dir || moved) return;
    moved = true; es.close();
    var el = document.createElement('div');
    el.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(23,20,15,.93);color:#fff;font:15px/1.5 system-ui,sans-serif;text-align:center;padding:24px';
    el.innerHTML = '<div><b style="font-size:18px">Scene Slate is now open for another project</b><br>Everything here was saved. Go back to the canvas and open it again for this project.</div>';
    document.body.appendChild(el);
    try { if (window.parent !== window) window.parent.postMessage({ kai_plugin: 'moved' }, '*'); } catch (err) {}
  });

  function call(method, c, id, body) {
    if (moved) return Promise.reject(new Error('Scene Slate is open for another project now'));
    return fetch('/api/db/' + c + '/' + encodeURIComponent(id), { method: method, headers: { 'content-type': 'application/json' }, body: body == null ? undefined : JSON.stringify(body), keepalive: true })
      .then(function (r) { if (!r.ok) throw new Error('save failed'); });
  }
  var db = {
    collection: function (c) {
      return { onSnapshot: function (cb) { (subs[c] = subs[c] || []).push(cb); if (got[c]) cb(snap(c)); return function () { subs[c] = subs[c].filter(function (x) { return x !== cb; }); }; } };
    },
    doc: function (p) {
      var i = p.indexOf('/'), c = p.slice(0, i), id = p.slice(i + 1);
      return {
        set: function (v) { (cols[c] = cols[c] || {})[id] = v; return call('PUT', c, id, v); },
        delete: function () { if (cols[c]) delete cols[c][id]; return call('DELETE', c, id); }
      };
    }
  };
  var meP = fetch('/api/me').then(function (r) { return r.json(); }).then(function (j) { return j.id || null; }, function () { return null; });
  var user = { id: function () { return meP; }, can: function () { return Promise.resolve(true); } };
  window.claude = { use: function (n) { return Promise.resolve(n === 'db' ? db : n === 'user' ? user : null); } };

  // what a browser remembers (open episodes, the last scene, a typed title) is per show: another project starts clean
  try {
    var here = (window.__SHOW__ || {}).home || '';
    if (localStorage.getItem('sh.home') !== here) {
      Object.keys(localStorage).filter(function (k) { return k.indexOf('sh.') === 0; }).forEach(function (k) { localStorage.removeItem(k); });
      localStorage.setItem('sh.home', here);
    }
  } catch (e) {}
})();

// ---------- Blocking Board: how the scene on screen was staged (a strip at the bottom right) ----------
// The page calls window.kaiScene(id | null) whenever it shows a scene (or leaves one). The strip says whether the
// board has that scene, shows each shot's frame and blocking line, and opens the scene's board (through KAI when
// Scene Slate runs inside it, else Blocking Board's own page).
(function () {
  'use strict';
  var cur = null, info = null, open = false, el = null, timer = null;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function board() {
    if (!cur) return;
    if (window.parent !== window) window.parent.postMessage({ kai_plugin: 'open', id: 'blocking-board', open: { slate: cur } }, '*');
    else window.open('http://127.0.0.1:5317/#slate=' + encodeURIComponent(cur), 'blocking-board');
  }
  function paint() {
    if (!el) {
      el = document.createElement('div'); el.id = 'kaiBB';
      el.style.cssText = 'position:fixed;right:14px;bottom:14px;z-index:60;max-width:min(430px,92vw);font:13px/1.4 system-ui,sans-serif;color:#EDE7DD';
      document.body.appendChild(el);
      el.addEventListener('click', function (e) {
        var a = e.target.closest('[data-bb]'); if (!a) return;
        if (a.dataset.bb === 'open') board(); else if (a.dataset.bb === 'toggle') { open = !open; paint(); }
        else if (a.dataset.bb === 'copy') { try { navigator.clipboard.writeText(a.dataset.text || ''); a.textContent = 'Copied'; setTimeout(function () { a.textContent = 'Copy'; }, 1200); } catch (err) {} }
      });
    }
    if (!cur || !info || !info.board) { el.style.display = 'none'; return; }
    el.style.display = '';
    var box = 'background:#211D18;border:1px solid #3A332B;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.45)';
    var btn = 'font:inherit;border:1px solid #4A4138;background:#2C2620;color:#EDE7DD;border-radius:7px;padding:4px 10px;cursor:pointer';
    if (!info.staged) { el.innerHTML = '<div style="' + box + ';padding:8px 10px;display:flex;gap:10px;align-items:center"><span>Not on the Blocking Board yet</span><button data-bb="open" style="' + btn + '">Stage it</button></div>'; return; }
    var head = '<div style="display:flex;gap:10px;align-items:center;padding:8px 10px"><b>Blocking Board</b><span style="opacity:.7">' + esc(info.ep + ' › ' + info.sc) + ' · ' + info.shots.length + ' shot' + (info.shots.length === 1 ? '' : 's') + '</span>'
      + '<span style="margin-left:auto;display:flex;gap:6px"><button data-bb="toggle" style="' + btn + '">' + (open ? 'Hide' : 'Blocking') + '</button><button data-bb="open" style="' + btn + '">Open</button></span></div>';
    var list = !open ? '' : '<div style="max-height:52vh;overflow:auto;border-top:1px solid #3A332B;padding:8px 10px;display:flex;flex-direction:column;gap:10px">'
      + (info.shots.length ? info.shots.map(function (s) {
        return '<div style="display:flex;gap:8px">' + (s.frame ? '<img src="' + esc(s.frame) + '" style="width:112px;aspect-ratio:16/9;object-fit:cover;border-radius:5px;flex:none;background:#000">' : '<div style="width:112px;aspect-ratio:16/9;border-radius:5px;flex:none;background:#2C2620;display:flex;align-items:center;justify-content:center;opacity:.6;font-size:11px">no frame</div>')
          + '<div style="min-width:0"><b>' + esc(s.name) + '</b> <span style="opacity:.6">' + esc(s.sec) + ' s</span><div style="opacity:.85;font-size:12px;margin:2px 0 4px">' + esc(s.blocking || 'No blocking yet') + '</div>'
          + (s.blocking ? '<button data-bb="copy" data-text="' + esc(s.blocking) + '" style="' + btn + ';padding:2px 8px;font-size:12px">Copy</button>' : '') + '</div></div>';
      }).join('') : '<span style="opacity:.7">Staged, no shots blocked yet.</span>') + '</div>';
    el.innerHTML = '<div style="' + box + '">' + head + list + '</div>';
  }
  function load() {
    if (!cur) { info = null; return paint(); }
    var want = cur;
    fetch('/api/blocking?scene=' + encodeURIComponent(want)).then(function (r) { return r.json(); }).then(function (j) { if (want === cur) { info = j; paint(); } }, function () {});
  }
  window.kaiScene = function (id) { if (id === cur) return; cur = id || null; info = null; paint(); load(); };
  // the board moves on while the slate is open: look again now and then, and when the window comes back
  clearInterval(timer); timer = setInterval(function () { if (cur && document.visibilityState === 'visible') load(); }, 8000);
  addEventListener('focus', load);
})();
