// Scene Slate's tab inside KAI (the canvas's left edge). KAI loads it as a plugin (../kai-plugin.json): it lives in
// Scene Slate's repo and is changed here, never in KAI's code.
// mount(el, kz) -> {setProject(key)}; kz is KAI's plugin kit: api, esc, toast, plugin.open({id, open}), plugin.index(id).
// Lists the show's episodes and scenes from kai-index.json; a click opens Scene Slate at that scene.
const ID = 'scene-slate';

export function mount(el, kz) {
  let key = null, data = null, busy = false, open = {};
  el.innerHTML = `<div class="fx">
    <button class="btn fx-go" data-a="open">🎞 Open Scene Slate</button>
    <div class="fx-h" style="margin-top:10px"><span data-show>Scenes</span><button class="btn sm ghost" data-a="reload" title="Reload">↻</button></div>
    <div class="dim" style="font-size:12px;margin:-4px 0 8px">Click a scene to open it</div>
    <div data-list></div></div>`;
  const list = el.querySelector('[data-list]'), showEl = el.querySelector('[data-show]');
  const groups = () => data?.index?.groups || [];

  async function load() {
    if (!key) { list.innerHTML = `<div class="fx-empty">Open a project first.</div>`; return; }
    if (busy) return; busy = true;
    try { data = await kz.plugin.index(ID); paint(); }
    catch (err) { list.innerHTML = `<div class="fx-empty">${kz.esc(err.message)}</div>`; }
    finally { busy = false; }
  }
  function paint() {
    showEl.textContent = data.index?.show ? `${data.index.show} · scenes` : 'Scenes';
    if (!data.installed) { list.innerHTML = `<div class="fx-empty">Scene Slate needs Node.js on this PC.</div>`; return; }
    if (!groups().length) { list.innerHTML = `<div class="fx-empty">No show in this project yet. Open Scene Slate to start.</div>`; return; }
    list.innerHTML = groups().map((g, i) => `<div class="fx-card" style="margin-bottom:6px;padding:8px 10px">
      <div class="fx-h" data-g="${i}" style="cursor:pointer;margin:0"><span>${open[g.name] ? '▾' : '▸'} ${kz.esc(g.name)}</span><small>${g.items.length}</small></div>
      ${open[g.name] ? `<div style="display:flex;flex-direction:column;gap:2px;margin-top:6px">${g.items.map((s, j) => `
        <button class="btn sm ghost" data-g="${i}" data-s="${j}" style="text-align:left;white-space:normal;line-height:1.3;padding:5px 6px" title="${kz.esc(s.info || '')}">
          <b>S${kz.esc(String(s.sc))}</b> ${kz.esc((s.title || '').replace(/^EP\d+\s+S\d+\s*[—–-]\s*/i, ''))}<br><span class="dim" style="font-size:11.5px">${kz.esc(s.info || '')}</span></button>`).join('')}</div>` : ''}</div>`).join('');
  }

  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'open') return key ? kz.plugin.open({ id: ID }) : kz.toast('Open a project first');
    if (a === 'reload') return load();
    const t = e.target.closest('[data-g]'); if (!t) return;
    const g = groups()[+t.dataset.g]; if (!g) return;
    if (t.dataset.s == null) { open[g.name] = !open[g.name]; return paint(); }
    const s = g.items[+t.dataset.s];
    if (s) kz.plugin.open({ id: ID, label: s.label, open: s.open });
  });
  addEventListener('focus', () => { if (key && el.offsetParent) load(); });

  return { setProject(k) { if (k !== key) { key = k; data = null; open = {}; } load(); } };
}
