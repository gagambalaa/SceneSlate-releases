// Scene Slate's server: serves the app and keeps a show's slate in one folder (in KAI: the project's KAI\Scene Slate\).
//   show.json            the show: { title: {...}, episodes: { "1": "Nothing to Lose", ... }, styles: { key, scene, anim } }
//   scenes/<id>.json     the authored scenes, one file each (globals, shots, keyframeSpecs ...)
//   cast.json            the cast
//   data/<collection>/<id>.json   what people change while working: scenes (edits over the authored scene), kf (keyframe
//                        approvals), notes, cfg (styles, title, owner). One small file per document, written at once.
//   kai-index.json       what the slate holds, for its tab in KAI and for other plugins (docs/PLUGIN_DATA.md)
// No dependencies. Every change is on disk before the request is answered; tabs follow each other through /api/events.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIR = path.resolve(process.env.SLATE_DIR || path.join(ROOT, 'show'));
const PORT = Number(process.env.SLATE_PORT) || 5318;
const COLLECTIONS = ['scenes', 'kf', 'notes', 'cfg'];
const ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' };

const readJson = (f, fallback) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return fallback; } };
function writeJson(f, v) {
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f + '.tmp', JSON.stringify(v, null, 1) + '\n');
  fs.renameSync(f + '.tmp', f);
}
const natural = (a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });

// ---------- the authored show ----------
function baseScenes() {
  const d = path.join(DIR, 'scenes');
  let files = []; try { files = fs.readdirSync(d).filter((f) => f.endsWith('.json')); } catch {}
  return files.sort(natural).map((f) => readJson(path.join(d, f), null)).filter((s) => s && s._file)
    .sort((a, b) => (a._ep - b._ep) || (a._sc - b._sc));
}
const show = () => readJson(path.join(DIR, 'show.json'), {});
function baseJs() { // the app reads the show as window.__SCENES__ ... (as the first Scene Slate did from its data scripts)
  const s = show(), LS = String.fromCharCode(0x2028), PS = String.fromCharCode(0x2029);
  const js = (v) => JSON.stringify(v).split(LS).join('\\' + 'u2028').split(PS).join('\\' + 'u2029');   // (the two characters a script can't hold raw)
  return `window.__SCENES__=${js(baseScenes())};\nwindow.__CAST__=${js(readJson(path.join(DIR, 'cast.json'), []))};\n`
    + `window.__STYLES__=${js(s.styles || {})};\nwindow.__SHOW__=${js({ title: s.title || {}, episodes: s.episodes || {}, home: DIR })};\n`;
}

// ---------- documents (what people change) ----------
const colDir = (c) => path.join(DIR, 'data', c);
function readCol(c) {
  const out = {};
  let files = []; try { files = fs.readdirSync(colDir(c)).filter((f) => f.endsWith('.json')); } catch {}
  for (const f of files) { const v = readJson(path.join(colDir(c), f), undefined); if (v !== undefined) out[f.slice(0, -5)] = v; }
  return out;
}
const clients = new Set();
const send = (res, event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
const pushTimers = {};
function pushCol(c) { // a moment later, once: several writes in a row are one update
  clearTimeout(pushTimers[c]);
  pushTimers[c] = setTimeout(() => { const docs = readCol(c); for (const r of clients) send(r, 'db', { col: c, docs }); if (c === 'scenes') scheduleIndex(); }, 60);
}
// files changed from outside (KAI bringing in another artist's edits): the tabs follow
for (const c of COLLECTIONS) { fs.mkdirSync(colDir(c), { recursive: true }); try { fs.watch(colDir(c), () => pushCol(c)); } catch {} }
setInterval(() => { for (const r of clients) r.write(': ping\n\n'); }, 15000).unref();

// the authored show itself changed on disk (an import, or KAI bringing in another artist's): open tabs load it again
let baseTimer = null;
const baseChanged = () => { clearTimeout(baseTimer); baseTimer = setTimeout(() => { for (const r of clients) send(r, 'base', {}); scheduleIndex(); }, 800); };
fs.mkdirSync(path.join(DIR, 'scenes'), { recursive: true });
try { fs.watch(path.join(DIR, 'scenes'), baseChanged); fs.watch(DIR, (ev, name) => { if (name === 'show.json' || name === 'cast.json') baseChanged(); }); } catch {}

// ---------- the slate's shape: scenes added, removed (kept aside, restorable), merged ----------
// A scene's id (its file name) never changes - KAI's tables, keyframe approvals, notes and the Blocking Board follow it.
// Only the numbers do: an episode's scenes are always 1..n in order, and a title "EP2 S3 — ..." follows its number.
// removed/<id>.json = a removed scene as it was, with _removed {at, by, ep, sc, into?} (into = merged into that scene).
const REMOVED = path.join(DIR, 'removed');
const pad2 = (n) => String(n).padStart(2, '0');
const sceneFile = (id) => path.join(DIR, 'scenes', `${id}.json`);
const retitle = (b) => { if (typeof b.title === 'string') b.title = b.title.replace(/^EP\s*\d+\s+S\s*\d+(?=\s*[\u2014\u2013-])/i, `EP${b._ep} S${b._sc}`); };
function putScene(b) { retitle(b); writeJson(sceneFile(b._file), b); }
function renumber(ep) {   // 1..n in their order
  baseScenes().filter((b) => b._ep === ep).sort((a, b) => a._sc - b._sc).forEach((b, i) => { if (b._sc !== i + 1) { b._sc = i + 1; putScene(b); } });
}
function sceneOrThrow(id) {
  const b = ID.test(id || '') ? readJson(sceneFile(id), null) : null;
  if (!b) throw Object.assign(new Error(`no scene "${id}"`), { status: 404 });
  return b;
}
function addScene({ ep, after, title }) {
  ep = Number(ep);
  if (!(ep >= 1 && ep < 1000)) throw Object.assign(new Error('which episode?'), { status: 400 });
  const list = baseScenes().filter((b) => b._ep === ep);
  const at = after ? (list.find((b) => b._file === after)?._sc ?? list.length) : list.length;
  for (const b of list) if (b._sc > at) { b._sc++; putScene(b); }
  const sc = at + 1, id = `ep${pad2(ep)}_n${Date.now().toString(36)}`;
  const b = { _file: id, _ep: ep, _sc: sc, title: `EP${ep} S${sc} \u2014 ${String(title || 'New scene').slice(0, 120)}`, globals: {},
    shots: [{ id: `${sc}-1`, sec: 5, type: 'WIDE', action: '', acting: '', camera: '', frame: '', light: '' }], keyframeSpecs: [] };
  putScene(b);
  return b;
}
function removeScene(id, by, into) {
  const b = sceneOrThrow(id);
  writeJson(path.join(REMOVED, `${id}.json`), { ...b, _removed: { at: Date.now(), by: by || null, ep: b._ep, sc: b._sc, ...(into ? { into } : {}) } });
  fs.rmSync(sceneFile(id));
  renumber(b._ep);
  return b;
}
function restoreScene(id) {
  const r = ID.test(id || '') ? readJson(path.join(REMOVED, `${id}.json`), null) : null;
  if (!r) throw Object.assign(new Error(`"${id}" isn't among the removed scenes`), { status: 404 });
  if (fs.existsSync(sceneFile(id))) throw Object.assign(new Error('it is back already'), { status: 409 });
  const { _removed: was = {}, ...b } = r;
  const list = baseScenes().filter((x) => x._ep === b._ep);
  const at = Math.max(1, Math.min(Number(was.sc) || list.length + 1, list.length + 1));
  for (const x of list) if (x._sc >= at) { x._sc++; putScene(x); }
  b._sc = at; putScene(b);
  fs.rmSync(path.join(REMOVED, `${id}.json`));
  return b;
}
// the second scene's shots after the first's (a shot id the first already has gets a letter), its keyframes and its
// edits along; the globals stay the first's. The second is kept aside as merged into the first.
function mergeScene(src, into, by) {
  if (src === into) throw Object.assign(new Error('pick another scene'), { status: 400 });
  const a = sceneOrThrow(into), b = sceneOrThrow(src);
  const have = new Set((a.shots || []).map((s) => String(s.id))), ren = {};
  const shots = (b.shots || []).map((s) => {
    let id = String(s.id), n = 0;
    while (have.has(id)) id = `${s.id}${'bcdefghij'[n++] || n}`;
    have.add(id); if (id !== String(s.id)) ren[s.id] = id;
    return { ...s, id };
  });
  const kfHave = new Set((a.keyframeSpecs || []).map((k) => k.id));
  const kfs = (b.keyframeSpecs || []).filter((k) => !kfHave.has(k.id)).map((k) => ({ ...k, shotId: ren[k.shotId] || k.shotId }));
  const splits = (v) => String(v || '').split(',').map((x) => x.trim()).filter(Boolean);
  const lastA = (a.shots || []).slice(-1)[0]?.id;
  if (lastA != null && shots.length) a.splitAfter = [...new Set([...splits(a.splitAfter), String(lastA), ...splits(b.splitAfter).map((x) => ren[x] || x)])].join(',');
  a.shots = [...(a.shots || []), ...shots];
  a.keyframeSpecs = [...(a.keyframeSpecs || []), ...kfs];
  a._merged = [...(a._merged || []), { id: src, at: Date.now() }];
  const oa = readJson(path.join(colDir('scenes'), `${into}.json`), null), ob = readJson(path.join(colDir('scenes'), `${src}.json`), null);
  if (ob) {   // (edits made over the second scene: its shots' come along; a changed keyframe list too)
    const o = oa || {};
    o.shots = { ...(o.shots || {}) };
    for (const [k, v] of Object.entries(ob.shots || {})) o.shots[ren[k] || k] = { ...(o.shots[ren[k] || k] || {}), ...v };
    if (o.keyframeSpecs || ob.keyframeSpecs) {
      const mine = o.keyframeSpecs || a.keyframeSpecs.filter((k) => !kfs.includes(k)), ids = new Set(mine.map((k) => k.id));
      o.keyframeSpecs = [...mine, ...(ob.keyframeSpecs || kfs).filter((k) => !ids.has(k.id)).map((k) => ({ ...k, shotId: ren[k.shotId] || k.shotId }))];
    }
    writeJson(path.join(colDir('scenes'), `${into}.json`), o);
  } else if (oa?.keyframeSpecs) {
    oa.keyframeSpecs = [...oa.keyframeSpecs, ...kfs];
    writeJson(path.join(colDir('scenes'), `${into}.json`), oa);
  }
  const o2 = readJson(path.join(colDir('scenes'), `${into}.json`), null);   // (a changed shot order / split of the first scene: the new shots join it)
  if (o2 && (Array.isArray(o2.order) || o2.splitAfter !== undefined)) {
    if (Array.isArray(o2.order)) o2.order = [...o2.order, ...shots.map((x) => x.id).filter((id) => !o2.order.includes(id))];
    if (o2.splitAfter !== undefined && lastA != null && shots.length)
      o2.splitAfter = [...new Set([...splits(o2.splitAfter), String(lastA), ...splits(ob?.splitAfter ?? b.splitAfter).map((x) => ren[x] || x)])].join(',');
    writeJson(path.join(colDir('scenes'), `${into}.json`), o2);
  }
  putScene(a);
  removeScene(src, by, into);
  return a;
}
const removedList = () => {
  let files = []; try { files = fs.readdirSync(REMOVED).filter((f) => f.endsWith('.json')); } catch {}
  return files.map((f) => readJson(path.join(REMOVED, f), null)).filter((r) => r && r._file)
    .map((r) => ({ id: r._file, title: r.title, ep: r._removed?.ep, sc: r._removed?.sc, at: r._removed?.at, by: r._removed?.by, into: r._removed?.into || null }))
    .sort((x, y) => (y.at || 0) - (x.at || 0));
};

// ---------- kai-index.json: episodes and scenes, for the tab in KAI and other plugins ----------
function writeIndex() {
  try {
    const s = show(), over = readCol('scenes'), eps = new Map();
    for (const b of baseScenes()) {
      const o = over[b._file] || {}, shots = b.shots || [];
      const sec = shots.reduce((t, x) => t + (Number((o.shots || {})[x.id]?.sec ?? x.sec) || 0), 0);
      const name = `EP${String(b._ep).padStart(2, '0')}${s.episodes?.[b._ep] ? ` · ${s.episodes[b._ep]}` : ''}`;
      if (!eps.has(name)) eps.set(name, []);
      eps.get(name).push({ key: b._file, label: `🎞 EP${b._ep} S${b._sc}`, title: b.title || '', info: `${shots.length} shot${shots.length === 1 ? '' : 's'} · ${Math.round(sec * 10) / 10} s`,
        open: { scene: b._file }, scene: { data: `scenes/${b._file}.json` }, ep: b._ep, sc: b._sc });
    }
    writeJson(path.join(DIR, 'kai-index.json'), { plugin: 'scene-slate', format: 1, updated: new Date().toISOString(), show: s.title?.title || '',
      groups: [...eps].map(([name, items]) => ({ name, items })) });
  } catch (e) { console.error(`[slate] index: ${e.message}`); }
}
// ---------- kai-canvases.json: the canvases KAI keeps for this show (see kai-plugin.json "canvases") ----------
// A sub canvas per episode (EP01 ...), and in it a Cards Table per scene, with a card for every keyframe of the scene
// and one for each video generation - so every picture and clip has its place before it's made. KAI makes what's
// missing and follows this file; what people put in the cards is theirs and is never taken away.
function writeCanvases() {
  try {
    const s = show(), over = readCol('scenes'), eps = new Map();
    const vertical = /vertical|9\s*[:x]\s*16/i.test(`${s.title?.format || ''} ${s.aspect || ''}`);
    const aspect = /^\d+:\d+$/.test(s.aspect || '') ? s.aspect : vertical ? '9:16' : '16:9';
    const pad = (n) => String(n).padStart(2, '0');
    for (const b of baseScenes()) {
      const o = over[b._file] || {};
      const specs = (o.keyframeSpecs || b.keyframeSpecs || []).filter((k) => k && k.id);
      const split = o.splitAfter !== undefined ? o.splitAfter : b.splitAfter;
      const gens = (split ? String(split).split(',').map((x) => x.trim()).filter(Boolean).length : 0) + 1;
      const cards = [...specs.map((k) => ({ key: `kf:${k.id}`, name: String(k.id) })),
        ...Array.from({ length: gens }, (_, i) => ({ key: `video:${i + 1}`, name: gens > 1 ? `Video ${i + 1}` : 'Video' }))];
      const name = `EP${pad(b._ep)}`;
      if (!eps.has(name)) eps.set(name, []);
      const short = String(b.title || '').replace(/^EP\s*\d+\s+S\s*\d+\s*[—–-]\s*/i, '');
      eps.get(name).push({ key: b._file, title: `${name} · SC${pad(b._sc)}${short ? ` · ${short}` : ''}`, aspect, cards });
    }
    const text = JSON.stringify({ plugin: 'scene-slate', format: 1, canvases: [...eps].map(([name, tables]) => ({ name, tables })) }, null, 1) + '\n';
    const f = path.join(DIR, 'kai-canvases.json');
    let old = null; try { old = fs.readFileSync(f, 'utf8'); } catch {}
    if (old !== text && eps.size) { fs.writeFileSync(f + '.tmp', text); fs.renameSync(f + '.tmp', f); }
  } catch (e) { console.error(`[slate] canvases: ${e.message}`); }
}

let indexTimer = null;
function scheduleIndex() { clearTimeout(indexTimer); indexTimer = setTimeout(() => { writeIndex(); writeCanvases(); }, 1500); }

// ---------- Blocking Board (the sibling plugin in the same KAI project): how a scene was staged ----------
// Its folder is read, never written: <project>\KAI\Blocking Board\ (kai-index.json says which board scene stages
// which slate scene; prompts\<EP>\<SC>.json has every shot's blocking; frames\<EP>\<SC>\ the pictures).
const BOARD = path.join(process.env.KAI_PROJECT_DIR || path.dirname(DIR), 'Blocking Board');
// the film's frame (the board's own pick, else this show's format - a vertical show is 9:16): the shape of its frames
function boardAspect() {
  const own = readJson(path.join(BOARD, 'library', 'format.json'), null)?.aspect;
  if (/^\d+(\.\d+)?:\d+$/.test(own || '')) return own;
  const show = readJson(path.join(DIR, 'show.json'), null);
  const t = `${show?.title?.format || ''} ${show?.title?.aspect || ''} ${show?.aspect || ''}`;
  if (/vertical|portrait|9\s*[:x]\s*16/i.test(t)) return '9:16';
  return (t.match(/\b(16:9|1:1|4:5|4:3|2\.39:1)\b/) || [])[1] || '16:9';
}
function blockingOf(id) {
  const idx = readJson(path.join(BOARD, 'kai-index.json'), null);
  if (!idx) return process.env.KAI_PROJECT_DIR ? { board: true, staged: false } : { board: false };   // (inside KAI: the board can be started from here)
  const item = (idx.groups || []).flatMap((g) => g.items || []).find((x) => x.slate === id);
  const aspect = boardAspect();
  if (!item || !item.open?.ep || !item.open?.sc) return { board: true, staged: false, aspect };   // (listed, not staged yet)
  const data = item.prompts?.data ? readJson(path.join(BOARD, item.prompts.data), null) : null;
  const have = new Set((item.frames || []).map((f) => f.key));
  return { board: true, staged: true, aspect, ep: item.open.ep, sc: item.open.sc, updated: data?.updated || idx.updated || null,
    main: have.has('main') ? `/api/blocking/frame?scene=${encodeURIComponent(id)}&name=main` : null,
    shots: (data?.shots || []).map((s) => ({ name: s.name, sec: s.sec, blocking: s.blocks?.blocking || '',
      frame: s.frames?.start && have.has(s.frames.start) ? `/api/blocking/frame?scene=${encodeURIComponent(id)}&name=${encodeURIComponent(s.frames.start)}` : null })) };
}

// ---------- who is working (for "by" on edits): KAI's signed-in name, else this PC's user ----------
let me = null;
async function whoAmI() {
  if (me) return me;
  try {
    const r = await fetch(`${process.env.KAI_URL}/api/state`, { signal: AbortSignal.timeout(3000) });
    const st = await r.json(); me = st.user?.name || st.user?.email || st.user || null;
    if (typeof me !== 'string') me = null;
  } catch {}
  return me || (me = os.userInfo().username);
}

// ---------- http ----------
const json = (res, code, v) => { res.writeHead(code, { 'content-type': MIME['.json'], 'cache-control': 'no-store' }); res.end(JSON.stringify(v)); };
const body = (req, limit = 2 * 1024 * 1024) => new Promise((ok, bad) => {
  const parts = []; let n = 0;
  req.on('data', (c) => { n += c.length; if (n > limit) { bad(Object.assign(new Error('too big'), { status: 413 })); req.destroy(); } else parts.push(c); });
  req.on('end', () => ok(Buffer.concat(parts))); req.on('error', bad);
});
function serveFile(res, base, rel) {
  const f = path.resolve(base, '.' + path.posix.normalize('/' + rel));
  if (f !== base && !f.startsWith(base + path.sep)) return json(res, 403, { ok: false });
  fs.readFile(f, (err, data) => {
    if (err) return json(res, 404, { ok: false, error: 'not found' });
    res.writeHead(200, { 'content-type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' }); res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x'), p = decodeURIComponent(url.pathname);
    // only this PC's pages talk to it (KAI's window, or a browser tab here)
    const origin = req.headers.origin;
    if (origin && !/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(origin)) return json(res, 403, { ok: false, error: 'not from this PC' });
    if (req.method === 'GET') {
      if (p === '/api/status') return json(res, 200, { ok: true, plugin: 'scene-slate', kai_dir: DIR, pid: process.pid, owner: process.env.CANVAS_OWNER || null, tabs: clients.size });
      if (p === '/api/me') return json(res, 200, { id: await whoAmI() });
      if (p === '/api/blocking') return json(res, 200, { ok: true, ...blockingOf(url.searchParams.get('scene') || '') });
      if (p === '/api/scene/removed') return json(res, 200, { ok: true, removed: removedList() });
      if (p === '/api/blocking/frame') { // one of the board's frames of that scene (a PNG)
        const b = blockingOf(url.searchParams.get('scene') || ''), name = url.searchParams.get('name') || '';
        if (!b.staged || !/^[\w.-]{1,90}$/.test(name)) return json(res, 404, { ok: false });
        return serveFile(res, path.join(BOARD, 'frames'), `${b.ep}/${b.sc}/${name}.png`);
      }
      if (p === '/base.js') { res.writeHead(200, { 'content-type': MIME['.js'], 'cache-control': 'no-store' }); return res.end(baseJs()); }
      if (p === '/api/events') {
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
        clients.add(res); req.on('close', () => clients.delete(res));
        send(res, 'home', { dir: DIR });
        for (const c of COLLECTIONS) send(res, 'db', { col: c, docs: readCol(c) });
        return;
      }
      return serveFile(res, path.join(ROOT, 'app'), p === '/' ? 'index.html' : p);
    }
    if (req.method === 'POST' && /^\/api\/scene\/(add|remove|restore|merge)$/.test(p)) {   // the slate's shape
      const b = JSON.parse(String(await body(req)) || '{}'), by = await whoAmI(), op = p.split('/').pop();
      try {
        const s = op === 'add' ? addScene(b) : op === 'remove' ? removeScene(b.id, by) : op === 'restore' ? restoreScene(b.id) : mergeScene(b.id, b.into, by);
        baseChanged(); scheduleIndex();
        return json(res, 200, { ok: true, id: s._file, ep: s._ep, sc: s._sc, title: s.title });
      } catch (e) { return json(res, e.status || 500, { ok: false, error: e.message }); }
    }
    if (p === '/api/flush' && req.method === 'POST') { if (indexTimer) { writeIndex(); writeCanvases(); } return json(res, 200, { ok: true }); }   // (documents are written as they arrive)
    const m = p.match(/^\/api\/db\/([a-z]+)\/(.+)$/);
    if (m && COLLECTIONS.includes(m[1]) && ID.test(m[2])) {
      const f = path.join(colDir(m[1]), `${m[2]}.json`);
      if (req.method === 'PUT') {
        const v = JSON.parse((await body(req)).toString('utf8'));
        if (!v || typeof v !== 'object') return json(res, 400, { ok: false, error: 'a document is an object' });
        writeJson(f, v); pushCol(m[1]); return json(res, 200, { ok: true });
      }
      if (req.method === 'DELETE') { try { fs.unlinkSync(f); } catch {} pushCol(m[1]); return json(res, 200, { ok: true }); }
    }
    json(res, 404, { ok: false, error: `no route ${req.method} ${p}` });
  } catch (e) { json(res, e.status || 500, { ok: false, error: e.message }); }
});

fs.mkdirSync(DIR, { recursive: true });
writeIndex(); writeCanvases();
for (const sig of ['SIGINT', 'SIGTERM', 'SIGBREAK', 'SIGHUP']) { try { process.once(sig, () => { if (indexTimer) { writeIndex(); writeCanvases(); } process.exit(0); }); } catch {} }
server.listen(PORT, '127.0.0.1', () => console.log(`[slate] http://127.0.0.1:${PORT}  ·  ${DIR}`));
