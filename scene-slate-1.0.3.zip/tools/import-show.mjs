#!/usr/bin/env node
// Puts a show into a Scene Slate folder (a KAI project's KAI\Scene Slate\): one file per scene, the cast, the show.
//   node tools/import-show.mjs <show.json export> <folder> [--replace]
// The export is one JSON file: { scenes: [...], cast: [...], styles: {key, scene, anim}, title: {...}, episodes: {...} }
// (window.json from the first Scene Slate's data works too: __SCENES__, __CAST__, __STYLES__).
// Scenes already in the folder are left alone unless --replace; what people changed (data\) is never touched.
import fs from 'node:fs';
import path from 'node:path';

const [src, dir] = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const replace = process.argv.includes('--replace');
if (!src || !dir) { console.error('usage: node tools/import-show.mjs <export.json> <Scene Slate folder> [--replace]'); process.exit(2); }
const d = JSON.parse(fs.readFileSync(src, 'utf8'));
const scenes = d.scenes || d.__SCENES__ || [], cast = d.cast || d.__CAST__ || [], styles = d.styles || d.__STYLES__ || {};
const write = (f, v) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v, null, 1) + '\n'); };

let n = 0, kept = 0;
for (const s of scenes) {
  if (!s || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/.test(s._file || '')) { console.warn('skipped a scene without a usable _file'); continue; }
  const f = path.join(dir, 'scenes', `${s._file}.json`);
  if (fs.existsSync(f) && !replace) { kept++; continue; }
  write(f, s); n++;
}
const showFile = path.join(dir, 'show.json');
const old = fs.existsSync(showFile) ? JSON.parse(fs.readFileSync(showFile, 'utf8')) : {};
write(showFile, { title: d.title || old.title || {}, episodes: d.episodes || old.episodes || {}, styles: Object.keys(styles).length ? styles : old.styles || {} });
if (cast.length && (replace || !fs.existsSync(path.join(dir, 'cast.json')))) write(path.join(dir, 'cast.json'), cast);
console.log(`${n} scene${n === 1 ? '' : 's'} written${kept ? `, ${kept} already there (kept)` : ''}; ${cast.length} cast; show.json updated -> ${dir}`);
