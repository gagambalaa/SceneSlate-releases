# Scene Slate's data

Everything Scene Slate knows about a show is in files in the project: `<project>\KAI\Scene Slate\`. Other KAI plugins
(Blocking Board, for one) and agents read them; nothing here needs Scene Slate to be running.

## The folder

| What | File |
| --- | --- |
| The show: title page, episode names, the three style blocks | `show.json` |
| A scene as authored: globals, shots, keyframe specs | `scenes\<id>.json` (`ep01_s01.json`) |
| The cast | `cast.json` |
| What people changed on a scene (edits over the authored one) | `data\scenes\<id>.json` |
| Keyframe approvals: status, the prompt that made the approved image, its link | `data\kf\<id>.json` |
| Notes on a scene (for the writer or an agent) | `data\notes\<id>.json` |
| Settings changed in the app: `styles`, `title`, `owner` | `data\cfg\<name>.json` |
| Every episode and scene, for KAI and other plugins | `kai-index.json` |
| The canvases KAI keeps for the show: a sub canvas per episode, a table per scene, its cards | `kai-canvases.json` |

`scenes\` and `cast.json` are the authored show (put in with `tools/import-show.mjs`); `data\` is the work on top.
The scene people see = the authored scene with its `data\scenes\<id>.json` laid over it:

- `globals`: each key in the edit replaces the authored one.
- `shots`: `order` (a list of shot ids) is the running order; `shots.<shot id>` holds changed fields of that shot.
- `splitAfter` (shot ids after which a new generation starts), `keyframes`, `kfSpecs`, `rv` (review status).

## A scene (`scenes\<id>.json`)

```json
{
  "_file": "ep01_s02", "_ep": 1, "_sc": 2,
  "title": "EP1 S2 — INT. LIA'S APARTMENT, MANILA · DAY",
  "globals": { "logline": "", "token": "", "location": "", "characters": "", "blocking": "", "screenDirection": "",
               "light": "", "physics": "", "audio": "", "constraints": "" },
  "shots": [ { "id": "2-1", "sec": 4.5, "type": "MED", "action": "", "acting": "", "camera": "", "frame": "",
               "light": "", "bg": "", "dialogue": [ { "who": "LIA", "line": "" } ], "token": "" } ],
  "splitAfter": "2-3", "soloPairs": "", "freshStart": false,
  "keyframeSpecs": [ { "id": "2-1", "shotId": "2-1", "at": "open", "why": "", "refs": "", "place": "", "frame": "",
                       "camera": "", "light": "", "motion": "", "excl": "" } ],
  "coverage": "", "coverageLabel": "", "coverageNote": "", "setups": "", "stems": "", "needsRepointing": "", "splitNote": "",
  "addressed": [ { "n": "", "at": "", "did": "" } ]
}
```

- A shot's `id` is `<scene>-<n>`; `sec` is seconds. `type` is the shot size (WIDE, MED, CLOSE, INSERT ...).
- `globals.blocking` is the first frame in words; `globals.location` and `globals.characters` name Higgsfield
  elements by their @handle (`@kitchen_pugon_day`).
- `keyframeSpecs[].at` is `open` or `close` (the first or the last frame of `shotId`).

## How to read it

- **From a plugin's panel in KAI**: `await kz.plugin.index('scene-slate')` → `index.groups[]` (episodes) `.items[]`
  (scenes: `key` = the scene id, `title`, `info`, `open: {scene}`, `scene.data` = the scene's file). Then
  `await kz.plugin.data('scene-slate', item.scene.data)`, and `data/scenes/<id>.json` for the edits over it.
- **Over HTTP**: `GET <KAI>/api/plugin/scene-slate/index?project=<canvas key>` and
  `GET <KAI>/api/plugin/scene-slate/data?project=<canvas key>&file=scenes/ep01_s02.json`.
- **From disk** (a plugin's own server): `<KAI_PROJECT_DIR>\Scene Slate\`. Read only - never write here from outside.

## With Blocking Board

Scene Slate is where the shots are written; Blocking Board is where they are staged. A scene's shots map onto Blocking
Board's slate one to one (`type`, `sec`, `frame`, `action`, `acting`, `camera`, `light`, `dialogue`), and Blocking
Board's measured blocking, camera and frames for the same scene are in its `prompts\<Episode>\<Scene>.json`
(see its `docs/PLUGIN_DATA.md`). The hand-over between the two isn't built yet.
